# Prompt Library – Full‑Stack (Next.js + Auth + Postgres)

1. `cp .env.example .env` y completa variables.
2. `pnpm i` y `pnpm db:push`
3. `pnpm dev`

Deploy en Vercel: importa el repo desde GitHub y define variables env. Luego `vercel run prisma migrate deploy`.
