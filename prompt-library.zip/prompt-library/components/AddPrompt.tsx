'use client'
import useSWRMutation from 'swr/mutation'
import React from 'react'

async function createFetcher(url: string, { arg }: any) {
  const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(arg) })
  if (!res.ok) throw new Error('Create failed')
  return res.json()
}

export function AddPrompt({ onCreated }: { onCreated: (p: any) => void }) {
  const { trigger, isMutating } = useSWRMutation('/api/prompts', createFetcher)
  const [form, setForm] = React.useState({ title: '', body: '', tags: '', model: '', category: '', lang: 'es' })

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.title.trim() || !form.body.trim()) return
    const p = await trigger({
      ...form,
      tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
    })
    onCreated(p)
    setForm({ title: '', body: '', tags: '', model: '', category: '', lang: 'es' })
  }

  return (
    <form onSubmit={submit} className="grid md:grid-cols-2 gap-3">
      <input className="border rounded-xl px-3 py-2" placeholder="Título" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
      <input className="border rounded-xl px-3 py-2" placeholder="Modelo (ej: GPT‑4o)" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} />
      <textarea className="border rounded-xl px-3 py-2 md:col-span-2 min-h-[120px]" placeholder="Prompt" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
      <input className="border rounded-xl px-3 py-2" placeholder="Tags (coma)" value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} />
      <div className="grid grid-cols-2 gap-3">
        <input className="border rounded-xl px-3 py-2" placeholder="Categoría" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
        <select className="border rounded-xl px-3 py-2" value={form.lang} onChange={(e) => setForm({ ...form, lang: e.target.value })}>
          <option value="es">ES</option>
          <option value="en">EN</option>
          <option value="pt">PT</option>
        </select>
      </div>
      <div className="md:col-span-2 flex items-center gap-2">
        <button type="submit" disabled={isMutating} className="px-4 py-2 rounded-xl border bg-black text-white disabled:opacity-40">Agregar prompt</button>
        <span className="text-sm text-gray-500">Tip: usá {"{variables}"} para campos editables.</span>
      </div>
    </form>
  )
}
