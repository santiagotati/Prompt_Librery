'use client'
import useSWRMutation from 'swr/mutation'

async function voteFetcher(url: string) {
  const res = await fetch(url, { method: 'POST' })
  if (!res.ok) throw new Error('Vote failed')
  return res.json()
}

export function PromptCard({ p }: { p: any }) {
  const { trigger, isMutating } = useSWRMutation(`/api/prompts/${p.id}/vote`, voteFetcher)

  async function onCopy() {
    await navigator.clipboard.writeText(p.body)
  }

  return (
    <div className="rounded-2xl border p-4 bg-white">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="font-semibold text-lg leading-tight">{p.title}</h3>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-gray-600">
            {p.model && <span className="px-2 py-1 rounded-full border">{p.model}</span>}
            {p.category && <span className="px-2 py-1 rounded-full border">{p.category}</span>}
            {p.lang && <span className="px-2 py-1 rounded-full border">{p.lang.toUpperCase()}</span>}
            {p.tags?.map((t: string) => (
              <span key={t} className="px-2 py-1 rounded-full border">#{t}</span>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={async () => {
              const data = await trigger()
              (p as any).upvotes = data.upvotes
            }}
            disabled={isMutating}
            className="px-3 py-1.5 rounded-xl border text-sm hover:bg-gray-50"
          >
            ▲ {p.upvotes ?? 0}
          </button>
          <button onClick={onCopy} className="px-3 py-1.5 rounded-xl border text-sm hover:bg-gray-50">Copiar</button>
        </div>
      </div>
      <pre className="mt-3 whitespace-pre-wrap text-sm bg-gray-50 p-3 rounded-xl border text-gray-900 max-h-80 overflow-auto">{p.body}</pre>
      <div className="mt-3 text-xs text-gray-500">{new Date(p.updatedAt ?? p.createdAt).toLocaleString()}</div>
    </div>
  )
}
