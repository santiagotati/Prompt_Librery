import './globals.css'
import { Providers } from '@/components/Providers'
import Link from 'next/link'
import { auth, signIn, signOut } from '@/lib/auth'

export const metadata = { title: 'Prompt Library', description: 'Comparte y busca prompts' }

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await auth()
  return (
    <html lang="es">
      <body className="min-h-screen bg-gray-50">
        <Providers>
          <header className="bg-white border-b">
            <div className="max-w-6xl mx-auto p-4 flex items-center justify-between">
              <Link href="/" className="font-bold">📚 Prompt Library</Link>
              <form action={async () => (session ? await signOut() : await signIn())}>
                <button className="px-3 py-1.5 rounded-xl border">
                  {session ? 'Cerrar sesión' : 'Ingresar con GitHub'}
                </button>
              </form>
            </div>
          </header>
          <main className="max-w-6xl mx-auto p-4 space-y-6">{children}</main>
          <footer className="text-center text-xs text-gray-500 py-8">Hecho con ❤️ • Next.js + Prisma + Vercel</footer>
        </Providers>
      </body>
    </html>
  )
}
