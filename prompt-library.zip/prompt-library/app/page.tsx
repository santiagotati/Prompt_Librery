'use client'
import useSWR from 'swr'
import { AddPrompt } from '@/components/AddPrompt'
import { PromptCard } from '@/components/PromptCard'
import { useState, useMemo } from 'react'

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function HomePage() {
  const [q, setQ] = useState('')
  const [model, setModel] = useState('')
  const [sort, setSort] = useState<'new' | 'top' | 'az'>('new')
  const [activeTags, setActiveTags] = useState<string[]>([])
  const { data: prompts, mutate } = useSWR(`/api/prompts?q=${encodeURIComponent(q)}&model=${model}&sort=${sort}&tags=${activeTags.join(',')}` , fetcher)
  const { data: tags } = useSWR('/api/tags', fetcher)

  const toggleTag = (t: string) => setActiveTags((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]))
  const allTags = useMemo(() => (tags || []).slice(0, 20), [tags])

  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <h2 className="font-semibold">Agregar nuevo</h2>
        <AddPrompt onCreated={() => mutate()} />
      </section>

      <section className="space-y-3">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <input className="border rounded-xl px-3 py-2 w-full" placeholder="Buscar por título o cuerpo…" value={q} onChange={(e) => setQ(e.target.value)} />
          <div className="flex flex-wrap items-center gap-2">
            <select className="border rounded-xl px-3 py-2" value={model} onChange={(e) => setModel(e.target.value)}>
              <option value="">Todos los modelos</option>
              <option>GPT‑4o</option>
              <option>GPT‑4o mini</option>
              <option>o3‑mini</option>
              <option>Llama 3.1</option>
              <option>Gemini 1.5</option>
            </select>
            <select className="border rounded-xl px-3 py-2" value={sort} onChange={(e) => setSort(e.target.value as any)}>
              <option value="new">Más nuevos</option>
              <option value="top">Más votados</option>
              <option value="az">A → Z</option>
            </select>
          </div>
          <div className="flex flex-wrap gap-2">
            {allTags?.map((t: string) => (
              <button key={t} onClick={() => toggleTag(t)} className={`px-2 py-1 rounded-full text-xs border ${activeTags.includes(t) ? 'bg-black text-white border-black' : ''}`}>#{t}</button>
            ))}
          </div>
        </div>
      </section>

      <section>
        {!prompts ? (
          <div className="text-gray-500">Cargando…</div>
        ) : prompts.length === 0 ? (
          <div className="text-center py-16 border border-dashed rounded-2xl">
            <div className="text-4xl">📭</div>
            <p className="mt-2 text-gray-700 font-medium">No hay prompts todavía</p>
            <p className="text-gray-500">Agregá el primero usando el formulario de arriba.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-3">
            {prompts.map((p: any) => (
              <PromptCard key={p.id} p={p} />
            ))}
          </div>
        )}
      </section>

      <section className="text-right">
        <a href="/api/export" className="px-3 py-2 rounded-xl border inline-block">Exportar JSON</a>
      </section>
    </div>
  )
}
