import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const prompts = await prisma.prompt.findMany({
    include: { tags: { include: { tag: true } }, _count: { select: { votes: true } } },
    orderBy: { updatedAt: 'desc' },
  })
  const json = prompts.map((p) => ({
    id: p.id,
    title: p.title,
    body: p.body,
    model: p.model,
    category: p.category,
    lang: p.lang,
    upvotes: p._count.votes,
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
    tags: p.tags.map((t) => t.tag.name),
  }))
  return new NextResponse(JSON.stringify(json, null, 2), {
    headers: { 'content-type': 'application/json', 'content-disposition': 'attachment; filename="prompts.json"' },
  })
}
