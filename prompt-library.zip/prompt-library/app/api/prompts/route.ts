import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { auth } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const q = searchParams.get('q') || ''
  const model = searchParams.get('model') || ''
  const sort = searchParams.get('sort') || 'new'
  const tags = (searchParams.get('tags') || '').split(',').filter(Boolean)

  const where: any = {}
  if (q) {
    where.OR = [
      { title: { contains: q, mode: 'insensitive' } },
      { body: { contains: q, mode: 'insensitive' } },
    ]
  }
  if (model) where.model = { equals: model, mode: 'insensitive' }
  if (tags.length) {
    where.tags = { some: { tag: { name: { in: tags, mode: 'insensitive' } } } }
  }

  const orderBy =
    sort === 'top'
      ? [{ votes: { _count: 'desc' } }, { updatedAt: 'desc' }]
      : sort === 'az'
      ? [{ title: 'asc' }]
      : [{ updatedAt: 'desc' }]

  const prompts = await prisma.prompt.findMany({
    where,
    include: {
      tags: { include: { tag: true } },
      _count: { select: { votes: true } },
      author: { select: { id: true, name: true, image: true } },
    },
    orderBy,
    take: 100,
  })

  return NextResponse.json(
    prompts.map((p) => ({
      ...p,
      tags: p.tags.map((t) => t.tag.name),
      upvotes: p._count.votes,
    }))
  )
}

export async function POST(req: NextRequest) {
  const session = await auth()
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const data = await req.json()
  const { title, body, model, category, lang, tags = [] } = data

  if (!title?.trim() || !body?.trim())
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 })

  const prompt = await prisma.prompt.create({
    data: {
      title: title.trim(),
      body: body.trim(),
      model: model?.trim() || null,
      category: category?.trim() || null,
      lang: lang?.trim() || 'es',
      authorId: (session.user as any).id,
      tags: {
        create: (tags as string[]).map((name) => ({
          tag: { connectOrCreate: { where: { name }, create: { name } } },
        })),
      },
    },
    include: { tags: { include: { tag: true } } },
  })

  return NextResponse.json({
    ...prompt,
    tags: prompt.tags.map((t) => t.tag.name),
  })
}
