import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { auth } from '@/lib/auth'

export async function POST(_: NextRequest, { params }: { params: { id: string } }) {
  const session = await auth()
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = (session.user as any).id as string
  const promptId = params.id

  try {
    await prisma.vote.create({ data: { userId, promptId } })
  } catch (e) {
    // Unique constraint -> already voted; ignore
  }

  const count = await prisma.vote.count({ where: { promptId } })
  return NextResponse.json({ upvotes: count })
}
